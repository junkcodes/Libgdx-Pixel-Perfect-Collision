package com.gameproject.game.States;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import java.util.Vector;

public class PlayState extends State {
    private Texture u,v;
    private int[][] map1, map2;
    private int x=700,y=200,c=0;
    private Vector xedge1, yedge1,xedge2,yedge2;

    private TextureColl test1, test2;
    private Collision col = new Collision();

    public PlayState(GameStateManager gsm){
        super(gsm);
        u = new Texture("xxxxx.png");
        v = new Texture("star.png");

        test1 = new TextureColl(u,700,200); // Just don't pass height and width if you dobn't want to resize the texture while rendering
        map1 = test1.getMap();
        xedge1 = test1.getEdgeX();
        yedge1 = test1.getEdgeY();

        test2 = new TextureColl(v,v.getWidth()/4,v.getHeight()/4); // Just don't pass height and width if you dobn't want to resize the texture while rendering
        map2 = test2.getMap();
        xedge2 = test2.getEdgeX();
        yedge2 = test2.getEdgeY();
    }

    @Override
    public void handleInput(){
        if(Gdx.input.isKeyPressed(Input.Keys.RIGHT)) x++;
        if(Gdx.input.isKeyPressed(Input.Keys.LEFT)) x--;
        if(Gdx.input.isKeyPressed(Input.Keys.UP)) y++;
        if(Gdx.input.isKeyPressed(Input.Keys.DOWN)) y--;
    }

    @Override
    public void update(float dt){
        handleInput();
    }

    @Override
    public void render(SpriteBatch sb) {
        Gdx.gl.glClearColor(1, 1, 1, 1);
        sb.begin();
        sb.draw(u,100,100,700,200);
        sb.draw(v,x,y,v.getWidth()/4,v.getHeight()/4);
        if(col.PixelPerfectColl(map1, xedge1, yedge1, 100, 100, map2, xedge2, yedge2, x, y) == 1){ // PixelPerfectColl(map1, xedge1, yedge1, positionX1, positionY1, map2, xedge2, yedge2, positionX2, positionY2)
            c++;
            System.out.println("Collision   "+c);
        }
        sb.end();
    }
    @Override
    public void dispose(){
        u.dispose();
    }
}
