package com.gameproject.game.States;

import java.util.Vector;

public class Collision {
    private int[][] map;
    private Vector xedge, yedge;
    private int ex,ey,mx,my;
    public int PixelPerfectColl(int[][] map1, Vector xedge1, Vector yedge1, int x1, int y1, int[][] map2, Vector xedge2, Vector yedge2, int x2, int y2){
        if(xedge1.size() < xedge2.size()){
            map = map2;
            xedge = xedge1;
            yedge = yedge1;
            ex = x1;
            ey = y1;
            mx = x2;
            my = y2;
        }
        else{
            map = map1;
            xedge = xedge2;
            yedge = yedge2;
            ex = x2;
            ey = y2;
            mx = x1;
            my = y1;
        }
        int size = xedge.size();
        for(int i=0; i < size; i++){
            int x = (Integer) xedge.get(i) + ex, y = (Integer) yedge.get(i) + ey;
            if(x - mx >= 0 && x - mx <= map.length - 1  && y - my >= 0 && y - my <= map[0].length - 1 ) if(map[x - mx][y - my] == 1) return 1;
        }
        return 0;
    }
}
